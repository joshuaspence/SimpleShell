#define __MYSHELL_H_
/*
    myshell.h

    Author:	Joshua Spence
	SID:	308216350
	
	This is the header file for the 'myshell' shell.
*/

#include	<stdio.h>
#include	<stdlib.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<string.h>
#include	<signal.h>

#define		MAX_ARGS			64								// maximum number of arguments (size of argument array)

#include	"cmd_internal.h"
#include	"utility.h"
#include	"strings.h"

process_information proc_info;									// information about child processes
FILE *input_redir;												// file for input redirection (stdin if null)
FILE *output_redir;												// file for output redirection (stdout if null)
char *path;														// path to the executable

// output the shell prompt
void output_shell_prompt(const char *);

// reallocate memory for the input buffer if required
char *get_input(char *, FILE *);

// check arguments for dont wait character
void check_for_dont_wait(char **);

// check arguments for input redirection
void check_for_input_redirection(char **);

// check arguments for output redirection
void check_for_output_redirection(char **);

// process an external command by passing it the external shell
int process_external_command(char **);

// display an error message that a command requiring an argument has been executed without an argument
void error_no_argument(const char *);

// display an error message that a command has been specified with an unknown argument
void error_unrecognised_argument(const char *, const char *);

// reset the process information
void reset_process_information(void);

// main function to run the shell
int main(int, char **);
